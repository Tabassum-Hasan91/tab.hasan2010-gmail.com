package com.niit;

public interface UserService 
{
	User getUser(Integer userId);
	void UpdateUser(Integer userId,String username);
}
