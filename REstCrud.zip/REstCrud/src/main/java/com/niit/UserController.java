package com.niit;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/user")
public class UserController 
{
	@Autowired
	UserService userService;
	
	@RequestMapping("/{id}")
	public User getUser(@PathVariable("id") Integer id)
	{
		return userService.getUser(id);
	}
	
	@RequestMapping(method=RequestMethod.PUT,value="")
	public void updateUser(@RequestParam(value="userid")String userId,
							@RequestParam(value="uname") String username)
	{
		Integer id=Integer.parseInt(userId);
		userService.UpdateUser(id, username);
	}
	
}
