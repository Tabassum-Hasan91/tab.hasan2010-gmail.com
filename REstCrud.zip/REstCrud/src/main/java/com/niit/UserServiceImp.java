package com.niit;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;
@Service
public class UserServiceImp implements UserService 
{
	public List<User> user;
	
	public UserServiceImp() {
		user=new ArrayList<>();
		user.add(new User(100,"Shruti"));
		user.add(new User(101,"Hema"));
		user.add(new User(102,"Kirti"));
	}

	@Override
	public User getUser(Integer userId) {
		//returns a user object
		return user.stream().filter(x->x.getUserId()==userId).findAny().
											orElse(new User(userId,"Not found"));
	}

	@Override
	public void UpdateUser(Integer userId, String username) {
		
		user.stream().filter(x->x.getUserId()==userId).findAny().orElseThrow(()->new RuntimeException("User not found")).setUsername(username);
	}

}
